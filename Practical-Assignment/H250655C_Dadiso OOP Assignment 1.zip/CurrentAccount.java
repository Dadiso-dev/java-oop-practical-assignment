public class CurrentAccount extends Account {
    private final double overdraftLimit;
    private static final double MONTHLY_FEE = 5.0;

    public CurrentAccount(String accountNumber, double balance, double overdraftLimit) {
        super(accountNumber, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal rejected: amount must be positive.");
            return;
        }
        if (balance - amount < -overdraftLimit) {
            System.out.println("Withdrawal of " + amount + " REJECTED on current account "
                    + accountNumber + ": would exceed the overdraft limit of "
                    + overdraftLimit + ".");
            return;
        }
        balance -= amount;
        if (balance < 0) {
            System.out.println("Withdrew " + amount + " from current account " + accountNumber
                    + " (now in overdraft).");
        } else {
            System.out.println("Withdrew " + amount + " from current account " + accountNumber);
        }
    }

    @Override
    public void endOfMonth() {
        balance -= MONTHLY_FEE;
        System.out.println("Current " + accountNumber + ": monthly fee of " + MONTHLY_FEE + " deducted.");
    }
}