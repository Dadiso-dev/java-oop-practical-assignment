public class SavingsAccount extends Account {
    private final double minimumBalance;
    private static final double INTEREST_RATE = 0.02; // 2% per month

    public SavingsAccount(String accountNumber, double balance, double minimumBalance) {
        super(accountNumber, balance);
        this.minimumBalance = minimumBalance;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal rejected: amount must be positive.");
            return;
        }
        if (balance - amount < minimumBalance) {
            System.out.println("Withdrawal of " + amount + " REJECTED on savings account "
                    + accountNumber + ": balance would fall below the minimum of "
                    + minimumBalance + ".");
            return;
        }
        balance -= amount;
        System.out.println("Withdrew " + amount + " from savings account " + accountNumber);
    }

    @Override
    public void endOfMonth() {
        double interest = balance * INTEREST_RATE;
        balance += interest;
        System.out.println("Savings " + accountNumber + ": interest of " + interest + " applied.");
    }
}