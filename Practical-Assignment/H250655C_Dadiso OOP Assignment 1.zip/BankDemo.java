import java.util.ArrayList;
import java.util.List;

public class BankDemo {
    public static void main(String[] args) {
        List<Account> accounts = new ArrayList<>();
        accounts.add(new SavingsAccount("SAV-001", 900.0, 500.0));
        accounts.add(new CurrentAccount("CUR-001", 100.0, 500.0));
        accounts.add(new SavingsAccount("SAV-002", 2000.0, 500.0));
        accounts.add(new CurrentAccount("CUR-002", 1000.0, 500.0));
        accounts.get(2).deposit(100.0);
        accounts.get(2).deposit(-50.0);

        System.out.println("=== Starting balances ===");
        for (Account a : accounts) {
            System.out.println(a.getAccountNumber() + ": " + a.getBalance());
        }

        System.out.println();
        System.out.println("=== Withdrawing 500 from every account ===");
        for (Account a : accounts) {
            a.withdraw(500.0);
            System.out.println("  Balance now: " + a.getBalance());
        }

        System.out.println();
        System.out.println("=== End of month processing ===");
        for (Account a : accounts) {
            a.endOfMonth();
            System.out.println("  Balance now: " + a.getBalance());
        }
    }
}